#########################################################
###         Parameters for matrixes creation         ####
#########################################################


tckgen_method = ["Probabilistic"]
atlas_list = ["Schaefer","Destrieux"]



parcellate_schaefer = True
createTensor = True
create_smallertck = True
create_vf = True

createFAmatrix = True
createSCmatrix = True
createRDmatrix = True
createADmatrix = True
createADCmatrix = True
createNODDImatrix = True
save_matrix = True

createMesh = True
viewSCConnectome = False
viewFAConnectome = False
viewFA = False