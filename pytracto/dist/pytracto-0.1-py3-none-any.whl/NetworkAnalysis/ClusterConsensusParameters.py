gamma_min = 0.5
gamma_max = 4
num_clusterings = 30
inverse = False
viewMat = True