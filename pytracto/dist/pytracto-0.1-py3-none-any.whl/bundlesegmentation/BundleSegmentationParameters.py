#########################################################
###         Parameters for bundle segmentation       ####
#########################################################

verbose = True
View5kTracts = False
ViewAllTracts = False
ViewTractSegTracts = False